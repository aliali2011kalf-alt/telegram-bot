ANF Mini App — Elegant Edition

Files:
- index.html — the ANF Telegram Mini App interface
- tonconnect-manifest.json — TON Connect manifest
- anf-logo.png — TON Connect icon (add your ANF logo PNG at repository root)

GitHub repository:
aliali2011kalf-alt/telegram-bot

GitHub Pages:
https://aliali2011kalf-alt.github.io/telegram-bot/

Important:
1. Upload index.html and tonconnect-manifest.json to the same folder (repository root).
2. Upload anf-logo.png to the same folder. Recommended square PNG.
3. The manifest URL must open directly in the browser.
4. The referral bot username is currently set to ANF_AIRDROP_BOT in index.html. Change BOT_USERNAME if your real bot username is different.
5. Withdrawals should only be enabled after server-side TON Connect ton_proof verification is implemented.
